
// Form submit handler
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the default form submission

    // Get data from input fields
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;

    // Check if any input field is empty
    if (name === '' || email === '' || message === '') {
        // If any field is empty, show an error message
        document.getElementById('form-message').textContent = 'Please fill out all fields.';
        document.getElementById('form-message').style.color = 'red';
    } else {
        // If all fields are filled, show a success message
        document.getElementById('form-message').textContent = 'Your message has been sent successfully.';
        document.getElementById('form-message').style.color = 'green';

        // Reset the form input fields after submission
        document.getElementById('contact-form').reset();

        // After a delay, hide the success message
        setTimeout(function() {
            document.getElementById('form-message').textContent = '';
        }, 5000);
    }
});

// Typing effect function
const typedTextElement = document.getElementById('typed-text');
const typedText = 'Web Developer, Designer, Creator';
let textIndex = 0;

function typeText() {
    if (textIndex < typedText.length) {
        typedTextElement.textContent += typedText.charAt(textIndex);
        textIndex++;
        setTimeout(typeText, 100);
    }
}

typeText();
